--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.17 (Homebrew)
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "ProjectAllotment";
--
-- Name: ProjectAllotment; Type: DATABASE; Schema: -; Owner: abhiramiriyer
--

CREATE DATABASE "ProjectAllotment" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "ProjectAllotment" OWNER TO abhiramiriyer;

\connect "ProjectAllotment"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: abhiramiriyer
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO abhiramiriyer;

--
-- Name: get_project_details(integer); Type: FUNCTION; Schema: public; Owner: abhiramiriyer
--

CREATE FUNCTION public.get_project_details(proj_id integer) RETURNS TABLE(project_id integer, title text, description text, min_cgpa integer, available_slots integer, students_per_team integer, faculty_id integer, prerequisite_courses integer[], document_names character varying[], document_paths text[])
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.project_id,
        p.title,
        p.description,
        p.min_cgpa,
        p.available_slots,
        p.students_per_team,
        p.faculty_id,
        ARRAY_AGG(DISTINCT pr.course_id) AS prerequisite_courses,
        ARRAY_AGG(DISTINCT pd.document_name) AS document_names,
        ARRAY_AGG(DISTINCT pd.document_path) AS document_paths
    FROM projects p
    LEFT JOIN faculty f ON p.faculty_id = f.faculty_id
    LEFT JOIN prereq pr ON p.project_id = pr.project_id
    LEFT JOIN project_documents pd ON p.project_id = pd.project_id
    WHERE p.project_id = proj_id
    GROUP BY p.project_id;
END; 
$$;


ALTER FUNCTION public.get_project_details(proj_id integer) OWNER TO abhiramiriyer;

--
-- Name: prevent_duplicate_application(); Type: FUNCTION; Schema: public; Owner: abhiramiriyer
--

CREATE FUNCTION public.prevent_duplicate_application() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- If a student is part of a team applying for this project, prevent individual application
    IF EXISTS (
        SELECT 1 FROM team_project_applications tpa
        JOIN team_members tm ON tpa.Team_id = tm.Team_id
        WHERE tm.Student_id = NEW.Student_id AND tpa.Project_id = NEW.Project_id
    ) THEN
        RAISE EXCEPTION 'Student has already applied for this project as part of a team';
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.prevent_duplicate_application() OWNER TO abhiramiriyer;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.courses (
    course_id integer NOT NULL,
    course_name character varying(50) NOT NULL,
    course_code character varying(5) NOT NULL,
    credits integer NOT NULL,
    CONSTRAINT check_credits CHECK ((credits > 0))
);


ALTER TABLE public.courses OWNER TO abhiramiriyer;

--
-- Name: department; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.department (
    dept_id integer NOT NULL,
    dept_name text NOT NULL
);


ALTER TABLE public.department OWNER TO abhiramiriyer;

--
-- Name: documents_applications; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.documents_applications (
    document_id integer NOT NULL,
    individual_application_id integer,
    team_application_id integer,
    document_name character varying(255) NOT NULL,
    document_url text,
    upload_timestamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT documents_applications_check CHECK ((((individual_application_id IS NOT NULL) AND (team_application_id IS NULL)) OR ((individual_application_id IS NULL) AND (team_application_id IS NOT NULL))))
);


ALTER TABLE public.documents_applications OWNER TO abhiramiriyer;

--
-- Name: documents_applications_document_id_seq; Type: SEQUENCE; Schema: public; Owner: abhiramiriyer
--

CREATE SEQUENCE public.documents_applications_document_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documents_applications_document_id_seq OWNER TO abhiramiriyer;

--
-- Name: documents_applications_document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abhiramiriyer
--

ALTER SEQUENCE public.documents_applications_document_id_seq OWNED BY public.documents_applications.document_id;


--
-- Name: faculty; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.faculty (
    faculty_id integer NOT NULL,
    firstname character varying(50) NOT NULL,
    lastname character varying(50) NOT NULL,
    email text NOT NULL,
    phone_no character varying(10) NOT NULL,
    department_id integer
);


ALTER TABLE public.faculty OWNER TO abhiramiriyer;

--
-- Name: prereq; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.prereq (
    project_id integer NOT NULL,
    course_id integer NOT NULL
);


ALTER TABLE public.prereq OWNER TO abhiramiriyer;

--
-- Name: project_applications; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.project_applications (
    application_id integer NOT NULL,
    student_id integer,
    project_id integer,
    application_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'Pending'::character varying,
    bio text,
    CONSTRAINT project_applications_status_check CHECK (((status)::text = ANY ((ARRAY['Pending'::character varying, 'Accepted'::character varying, 'Rejected'::character varying])::text[])))
);


ALTER TABLE public.project_applications OWNER TO abhiramiriyer;

--
-- Name: project_applications_application_id_seq; Type: SEQUENCE; Schema: public; Owner: abhiramiriyer
--

CREATE SEQUENCE public.project_applications_application_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.project_applications_application_id_seq OWNER TO abhiramiriyer;

--
-- Name: project_applications_application_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abhiramiriyer
--

ALTER SEQUENCE public.project_applications_application_id_seq OWNED BY public.project_applications.application_id;


--
-- Name: project_dept; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.project_dept (
    project_id integer NOT NULL,
    dept_id integer NOT NULL
);


ALTER TABLE public.project_dept OWNER TO abhiramiriyer;

--
-- Name: project_details; Type: VIEW; Schema: public; Owner: abhiramiriyer
--

CREATE VIEW public.project_details AS
SELECT
    NULL::integer AS project_id,
    NULL::text AS title,
    NULL::text AS description,
    NULL::numeric(4,2) AS min_cgpa,
    NULL::integer AS available_slots,
    NULL::integer AS students_per_team,
    NULL::integer AS faculty_id,
    NULL::integer AS min_year,
    NULL::integer[] AS prerequisite_courses,
    NULL::character varying[] AS document_names,
    NULL::text[] AS document_paths;


ALTER VIEW public.project_details OWNER TO abhiramiriyer;

--
-- Name: project_documents; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.project_documents (
    document_id integer NOT NULL,
    project_id integer,
    document_name character varying(255) NOT NULL,
    document_path text NOT NULL,
    uploaded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.project_documents OWNER TO abhiramiriyer;

--
-- Name: project_documents_document_id_seq; Type: SEQUENCE; Schema: public; Owner: abhiramiriyer
--

CREATE SEQUENCE public.project_documents_document_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.project_documents_document_id_seq OWNER TO abhiramiriyer;

--
-- Name: project_documents_document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abhiramiriyer
--

ALTER SEQUENCE public.project_documents_document_id_seq OWNED BY public.project_documents.document_id;


--
-- Name: projects_project_id_seq; Type: SEQUENCE; Schema: public; Owner: abhiramiriyer
--

CREATE SEQUENCE public.projects_project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projects_project_id_seq OWNER TO abhiramiriyer;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.projects (
    project_id integer DEFAULT nextval('public.projects_project_id_seq'::regclass) NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    min_cgpa numeric(4,2) NOT NULL,
    available_slots integer NOT NULL,
    students_per_team integer NOT NULL,
    faculty_id integer,
    min_year integer,
    CONSTRAINT projects_available_slots_check CHECK ((available_slots >= 0)),
    CONSTRAINT projects_min_cgpa_check CHECK (((min_cgpa >= (0)::numeric) AND (min_cgpa <= (10)::numeric))),
    CONSTRAINT projects_min_sem_check CHECK (((min_year >= 1) AND (min_year <= 20))),
    CONSTRAINT projects_students_per_team_check CHECK ((students_per_team >= 1))
);


ALTER TABLE public.projects OWNER TO abhiramiriyer;

--
-- Name: student_courses; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.student_courses (
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    grade character(1) NOT NULL,
    CONSTRAINT check_grade CHECK ((grade = ANY (ARRAY['S'::bpchar, 'A'::bpchar, 'B'::bpchar, 'C'::bpchar, 'D'::bpchar, 'E'::bpchar, 'F'::bpchar, 'I'::bpchar])))
);


ALTER TABLE public.student_courses OWNER TO abhiramiriyer;

--
-- Name: students; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.students (
    roll_no integer NOT NULL,
    firstname character varying(50) NOT NULL,
    lastname character varying(50) NOT NULL,
    email text NOT NULL,
    phone_no character varying(10) NOT NULL,
    department_id integer,
    year integer NOT NULL,
    cgpa numeric(4,2) NOT NULL,
    CONSTRAINT check_cgpa CHECK (((cgpa >= (0)::numeric) AND (cgpa <= (10)::numeric))),
    CONSTRAINT check_semester CHECK (((year >= 1) AND (year <= 8)))
);


ALTER TABLE public.students OWNER TO abhiramiriyer;

--
-- Name: team_members; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.team_members (
    team_id integer NOT NULL,
    student_id integer NOT NULL
);


ALTER TABLE public.team_members OWNER TO abhiramiriyer;

--
-- Name: team_project_applications; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.team_project_applications (
    application_id integer NOT NULL,
    team_id integer,
    project_id integer,
    application_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'Pending'::character varying,
    bio text,
    CONSTRAINT team_project_applications_status_check CHECK (((status)::text = ANY ((ARRAY['Pending'::character varying, 'Accepted'::character varying, 'Rejected'::character varying])::text[])))
);


ALTER TABLE public.team_project_applications OWNER TO abhiramiriyer;

--
-- Name: team_project_applications_application_id_seq; Type: SEQUENCE; Schema: public; Owner: abhiramiriyer
--

CREATE SEQUENCE public.team_project_applications_application_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.team_project_applications_application_id_seq OWNER TO abhiramiriyer;

--
-- Name: team_project_applications_application_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abhiramiriyer
--

ALTER SEQUENCE public.team_project_applications_application_id_seq OWNED BY public.team_project_applications.application_id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.teams (
    team_id integer NOT NULL,
    team_name character varying(100) NOT NULL
);


ALTER TABLE public.teams OWNER TO abhiramiriyer;

--
-- Name: teams_team_id_seq; Type: SEQUENCE; Schema: public; Owner: abhiramiriyer
--

CREATE SEQUENCE public.teams_team_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teams_team_id_seq OWNER TO abhiramiriyer;

--
-- Name: teams_team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abhiramiriyer
--

ALTER SEQUENCE public.teams_team_id_seq OWNED BY public.teams.team_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: abhiramiriyer
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    password text NOT NULL,
    user_type character varying(10) NOT NULL,
    student_id integer,
    faculty_id integer,
    CONSTRAINT check_user_type CHECK (((((user_type)::text = 'student'::text) AND (student_id IS NOT NULL) AND (faculty_id IS NULL)) OR (((user_type)::text = 'faculty'::text) AND (faculty_id IS NOT NULL) AND (student_id IS NULL)))),
    CONSTRAINT users_user_type_check CHECK (((user_type)::text = ANY ((ARRAY['student'::character varying, 'faculty'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO abhiramiriyer;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: abhiramiriyer
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO abhiramiriyer;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abhiramiriyer
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: documents_applications document_id; Type: DEFAULT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.documents_applications ALTER COLUMN document_id SET DEFAULT nextval('public.documents_applications_document_id_seq'::regclass);


--
-- Name: project_applications application_id; Type: DEFAULT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.project_applications ALTER COLUMN application_id SET DEFAULT nextval('public.project_applications_application_id_seq'::regclass);


--
-- Name: project_documents document_id; Type: DEFAULT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.project_documents ALTER COLUMN document_id SET DEFAULT nextval('public.project_documents_document_id_seq'::regclass);


--
-- Name: team_project_applications application_id; Type: DEFAULT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.team_project_applications ALTER COLUMN application_id SET DEFAULT nextval('public.team_project_applications_application_id_seq'::regclass);


--
-- Name: teams team_id; Type: DEFAULT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.teams ALTER COLUMN team_id SET DEFAULT nextval('public.teams_team_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.courses (course_id, course_name, course_code, credits) FROM stdin;
\.
COPY public.courses (course_id, course_name, course_code, credits) FROM '$$PATH$$/3824.dat';

--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.department (dept_id, dept_name) FROM stdin;
\.
COPY public.department (dept_id, dept_name) FROM '$$PATH$$/3819.dat';

--
-- Data for Name: documents_applications; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.documents_applications (document_id, individual_application_id, team_application_id, document_name, document_url, upload_timestamp) FROM stdin;
\.
COPY public.documents_applications (document_id, individual_application_id, team_application_id, document_name, document_url, upload_timestamp) FROM '$$PATH$$/3838.dat';

--
-- Data for Name: faculty; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.faculty (faculty_id, firstname, lastname, email, phone_no, department_id) FROM stdin;
\.
COPY public.faculty (faculty_id, firstname, lastname, email, phone_no, department_id) FROM '$$PATH$$/3821.dat';

--
-- Data for Name: prereq; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.prereq (project_id, course_id) FROM stdin;
\.
COPY public.prereq (project_id, course_id) FROM '$$PATH$$/3827.dat';

--
-- Data for Name: project_applications; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.project_applications (application_id, student_id, project_id, application_date, status, bio) FROM stdin;
\.
COPY public.project_applications (application_id, student_id, project_id, application_date, status, bio) FROM '$$PATH$$/3834.dat';

--
-- Data for Name: project_dept; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.project_dept (project_id, dept_id) FROM stdin;
\.
COPY public.project_dept (project_id, dept_id) FROM '$$PATH$$/3840.dat';

--
-- Data for Name: project_documents; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.project_documents (document_id, project_id, document_name, document_path, uploaded_at) FROM stdin;
\.
COPY public.project_documents (document_id, project_id, document_name, document_path, uploaded_at) FROM '$$PATH$$/3829.dat';

--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.projects (project_id, title, description, min_cgpa, available_slots, students_per_team, faculty_id, min_year) FROM stdin;
\.
COPY public.projects (project_id, title, description, min_cgpa, available_slots, students_per_team, faculty_id, min_year) FROM '$$PATH$$/3826.dat';

--
-- Data for Name: student_courses; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.student_courses (student_id, course_id, grade) FROM stdin;
\.
COPY public.student_courses (student_id, course_id, grade) FROM '$$PATH$$/3825.dat';

--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.students (roll_no, firstname, lastname, email, phone_no, department_id, year, cgpa) FROM stdin;
\.
COPY public.students (roll_no, firstname, lastname, email, phone_no, department_id, year, cgpa) FROM '$$PATH$$/3820.dat';

--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.team_members (team_id, student_id) FROM stdin;
\.
COPY public.team_members (team_id, student_id) FROM '$$PATH$$/3832.dat';

--
-- Data for Name: team_project_applications; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.team_project_applications (application_id, team_id, project_id, application_date, status, bio) FROM stdin;
\.
COPY public.team_project_applications (application_id, team_id, project_id, application_date, status, bio) FROM '$$PATH$$/3836.dat';

--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.teams (team_id, team_name) FROM stdin;
\.
COPY public.teams (team_id, team_name) FROM '$$PATH$$/3831.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: abhiramiriyer
--

COPY public.users (user_id, password, user_type, student_id, faculty_id) FROM stdin;
\.
COPY public.users (user_id, password, user_type, student_id, faculty_id) FROM '$$PATH$$/3823.dat';

--
-- Name: documents_applications_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abhiramiriyer
--

SELECT pg_catalog.setval('public.documents_applications_document_id_seq', 7, true);


--
-- Name: project_applications_application_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abhiramiriyer
--

SELECT pg_catalog.setval('public.project_applications_application_id_seq', 33, true);


--
-- Name: project_documents_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abhiramiriyer
--

SELECT pg_catalog.setval('public.project_documents_document_id_seq', 3, true);


--
-- Name: projects_project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abhiramiriyer
--

SELECT pg_catalog.setval('public.projects_project_id_seq', 26, true);


--
-- Name: team_project_applications_application_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abhiramiriyer
--

SELECT pg_catalog.setval('public.team_project_applications_application_id_seq', 1, false);


--
-- Name: teams_team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abhiramiriyer
--

SELECT pg_catalog.setval('public.teams_team_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abhiramiriyer
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, false);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (course_id);


--
-- Name: department department_dept_name_key; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_dept_name_key UNIQUE (dept_name);


--
-- Name: department department_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_pkey PRIMARY KEY (dept_id);


--
-- Name: documents_applications documents_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.documents_applications
    ADD CONSTRAINT documents_applications_pkey PRIMARY KEY (document_id);


--
-- Name: faculty faculty_email_key; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.faculty
    ADD CONSTRAINT faculty_email_key UNIQUE (email);


--
-- Name: faculty faculty_phone_no_key; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.faculty
    ADD CONSTRAINT faculty_phone_no_key UNIQUE (phone_no);


--
-- Name: faculty faculty_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.faculty
    ADD CONSTRAINT faculty_pkey PRIMARY KEY (faculty_id);


--
-- Name: student_courses pk_student_course; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.student_courses
    ADD CONSTRAINT pk_student_course PRIMARY KEY (student_id, course_id, grade);


--
-- Name: prereq prereq_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.prereq
    ADD CONSTRAINT prereq_pkey PRIMARY KEY (project_id, course_id);


--
-- Name: project_applications project_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.project_applications
    ADD CONSTRAINT project_applications_pkey PRIMARY KEY (application_id);


--
-- Name: project_applications project_applications_student_id_project_id_key; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.project_applications
    ADD CONSTRAINT project_applications_student_id_project_id_key UNIQUE (student_id, project_id);


--
-- Name: project_dept project_dept_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.project_dept
    ADD CONSTRAINT project_dept_pkey PRIMARY KEY (project_id, dept_id);


--
-- Name: project_documents project_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.project_documents
    ADD CONSTRAINT project_documents_pkey PRIMARY KEY (document_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (project_id);


--
-- Name: projects projects_title_key; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_title_key UNIQUE (title);


--
-- Name: students students_phone_no_key; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_phone_no_key UNIQUE (phone_no);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (roll_no);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (team_id, student_id);


--
-- Name: team_project_applications team_project_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.team_project_applications
    ADD CONSTRAINT team_project_applications_pkey PRIMARY KEY (application_id);


--
-- Name: team_project_applications team_project_applications_team_id_project_id_key; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.team_project_applications
    ADD CONSTRAINT team_project_applications_team_id_project_id_key UNIQUE (team_id, project_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (team_id);


--
-- Name: teams teams_team_name_key; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_team_name_key UNIQUE (team_name);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: project_details _RETURN; Type: RULE; Schema: public; Owner: abhiramiriyer
--

CREATE OR REPLACE VIEW public.project_details AS
 SELECT p.project_id,
    p.title,
    p.description,
    p.min_cgpa,
    p.available_slots,
    p.students_per_team,
    p.faculty_id,
    p.min_year,
    array_agg(DISTINCT pr.course_id) AS prerequisite_courses,
    array_agg(DISTINCT pd.document_name) AS document_names,
    array_agg(DISTINCT pd.document_path) AS document_paths
   FROM (((public.projects p
     LEFT JOIN public.faculty f ON ((p.faculty_id = f.faculty_id)))
     LEFT JOIN public.prereq pr ON ((p.project_id = pr.project_id)))
     LEFT JOIN public.project_documents pd ON ((p.project_id = pd.project_id)))
  GROUP BY p.project_id, f.firstname;


--
-- Name: project_applications check_individual_application; Type: TRIGGER; Schema: public; Owner: abhiramiriyer
--

CREATE TRIGGER check_individual_application BEFORE INSERT ON public.project_applications FOR EACH ROW EXECUTE FUNCTION public.prevent_duplicate_application();


--
-- Name: student_courses fk_course; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.student_courses
    ADD CONSTRAINT fk_course FOREIGN KEY (course_id) REFERENCES public.courses(course_id);


--
-- Name: prereq fk_course; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.prereq
    ADD CONSTRAINT fk_course FOREIGN KEY (course_id) REFERENCES public.courses(course_id) ON DELETE CASCADE;


--
-- Name: students fk_dept; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT fk_dept FOREIGN KEY (department_id) REFERENCES public.department(dept_id);


--
-- Name: faculty fk_dept; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.faculty
    ADD CONSTRAINT fk_dept FOREIGN KEY (department_id) REFERENCES public.department(dept_id);


--
-- Name: project_dept fk_dept; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.project_dept
    ADD CONSTRAINT fk_dept FOREIGN KEY (dept_id) REFERENCES public.department(dept_id);


--
-- Name: users fk_faculty; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_faculty FOREIGN KEY (faculty_id) REFERENCES public.faculty(faculty_id);


--
-- Name: projects fk_faculty; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT fk_faculty FOREIGN KEY (faculty_id) REFERENCES public.faculty(faculty_id) ON DELETE CASCADE;


--
-- Name: documents_applications fk_individual_application; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.documents_applications
    ADD CONSTRAINT fk_individual_application FOREIGN KEY (individual_application_id) REFERENCES public.project_applications(application_id) ON DELETE CASCADE;


--
-- Name: prereq fk_project; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.prereq
    ADD CONSTRAINT fk_project FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: project_applications fk_project; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.project_applications
    ADD CONSTRAINT fk_project FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: team_project_applications fk_project; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.team_project_applications
    ADD CONSTRAINT fk_project FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: project_dept fk_project_dept; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.project_dept
    ADD CONSTRAINT fk_project_dept FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: project_documents fk_project_docs; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.project_documents
    ADD CONSTRAINT fk_project_docs FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: users fk_student; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_student FOREIGN KEY (student_id) REFERENCES public.students(roll_no);


--
-- Name: student_courses fk_student; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.student_courses
    ADD CONSTRAINT fk_student FOREIGN KEY (student_id) REFERENCES public.students(roll_no);


--
-- Name: team_members fk_student; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT fk_student FOREIGN KEY (student_id) REFERENCES public.students(roll_no) ON DELETE CASCADE;


--
-- Name: project_applications fk_student; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.project_applications
    ADD CONSTRAINT fk_student FOREIGN KEY (student_id) REFERENCES public.students(roll_no) ON DELETE CASCADE;


--
-- Name: team_members fk_team; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT fk_team FOREIGN KEY (team_id) REFERENCES public.teams(team_id) ON DELETE CASCADE;


--
-- Name: team_project_applications fk_team; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.team_project_applications
    ADD CONSTRAINT fk_team FOREIGN KEY (team_id) REFERENCES public.teams(team_id) ON DELETE CASCADE;


--
-- Name: documents_applications fk_team_application; Type: FK CONSTRAINT; Schema: public; Owner: abhiramiriyer
--

ALTER TABLE ONLY public.documents_applications
    ADD CONSTRAINT fk_team_application FOREIGN KEY (team_application_id) REFERENCES public.team_project_applications(application_id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: abhiramiriyer
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;
GRANT ALL ON SCHEMA public TO projectallotmentportal;


--
-- Name: TABLE courses; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.courses TO projectallotmentportal;


--
-- Name: TABLE department; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.department TO projectallotmentportal;


--
-- Name: TABLE documents_applications; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.documents_applications TO projectallotmentportal;


--
-- Name: SEQUENCE documents_applications_document_id_seq; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT ALL ON SEQUENCE public.documents_applications_document_id_seq TO projectallotmentportal;


--
-- Name: TABLE faculty; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.faculty TO projectallotmentportal;


--
-- Name: TABLE prereq; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.prereq TO projectallotmentportal;


--
-- Name: TABLE project_applications; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.project_applications TO projectallotmentportal;


--
-- Name: SEQUENCE project_applications_application_id_seq; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT ALL ON SEQUENCE public.project_applications_application_id_seq TO projectallotmentportal;


--
-- Name: TABLE project_dept; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT ON TABLE public.project_dept TO projectallotmentportal;


--
-- Name: TABLE project_details; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.project_details TO projectallotmentportal;


--
-- Name: TABLE project_documents; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.project_documents TO projectallotmentportal;


--
-- Name: SEQUENCE project_documents_document_id_seq; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT ALL ON SEQUENCE public.project_documents_document_id_seq TO projectallotmentportal;


--
-- Name: SEQUENCE projects_project_id_seq; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT ALL ON SEQUENCE public.projects_project_id_seq TO projectallotmentportal;


--
-- Name: TABLE projects; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.projects TO projectallotmentportal;


--
-- Name: TABLE student_courses; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.student_courses TO projectallotmentportal;


--
-- Name: TABLE students; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.students TO projectallotmentportal;


--
-- Name: TABLE team_members; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.team_members TO projectallotmentportal;


--
-- Name: TABLE team_project_applications; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.team_project_applications TO projectallotmentportal;


--
-- Name: SEQUENCE team_project_applications_application_id_seq; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT ALL ON SEQUENCE public.team_project_applications_application_id_seq TO projectallotmentportal;


--
-- Name: TABLE teams; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.teams TO projectallotmentportal;


--
-- Name: SEQUENCE teams_team_id_seq; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT ALL ON SEQUENCE public.teams_team_id_seq TO projectallotmentportal;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE public.users TO projectallotmentportal;


--
-- Name: SEQUENCE users_user_id_seq; Type: ACL; Schema: public; Owner: abhiramiriyer
--

GRANT ALL ON SEQUENCE public.users_user_id_seq TO projectallotmentportal;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: abhiramiriyer
--

ALTER DEFAULT PRIVILEGES FOR ROLE abhiramiriyer IN SCHEMA public GRANT ALL ON SEQUENCES TO projectallotmentportal;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: abhiramiriyer
--

ALTER DEFAULT PRIVILEGES FOR ROLE abhiramiriyer IN SCHEMA public GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO projectallotmentportal;


--
-- PostgreSQL database dump complete
--

